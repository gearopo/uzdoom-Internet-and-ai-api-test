UZDoom NetHub - MT管理器项目包

目录：
UZDoom_NetHub/
├── UZDoom_NetHub_v0_1.pk3   ← 直接复制到 UZDoom 的游戏目录使用
└── PK3_Source/              ← MT管理器可直接查看/修改的 PK3 源文件

在 MT 管理器中：
1. 解压本 ZIP。
2. 进入 UZDoom_NetHub/。
3. 将 UZDoom_NetHub_v0_1.pk3 复制到 UZDoom 的 mod/WAD 文件目录。
4. 在 UZDoom 中加载该 PK3。
5. 如果要修改内容，可以进入 PK3_Source/ 修改对应文件。
6. 修改完成后，把 PK3_Source 内的内容重新压缩为 ZIP，再将扩展名改成 .pk3。

注意：
- MT管理器可以编辑/压缩 PK3，但不能凭空给 UZDoom 增加网络协议。
- 真正的 Internet 联机、远程 Mod 下载、AI API、超大规模玩家同步仍需要 UZDoom 引擎插件/源码分支或桥接程序。
- 不要从不可信服务器自动加载原生代码；远程 WAD/PK3 应做 SHA-256 校验和用户确认。
