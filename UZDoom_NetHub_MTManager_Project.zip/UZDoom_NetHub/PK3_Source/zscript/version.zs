const NETMOD_VERSION = "0.1-prototype";
