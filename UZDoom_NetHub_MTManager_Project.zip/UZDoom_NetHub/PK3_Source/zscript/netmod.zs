class NetModState : StaticEventHandler
{
    override void WorldLoaded(WorldEvent e)
    {
        if (CVar.GetCVar("netmod_enabled", players[consoleplayer]) > 0)
        {
            Console.Printf("NetHub: client shell active.");
            Console.Printf("NetHub: server = %s", CVar.GetCVar("netmod_server", players[consoleplayer]).GetString());
            Console.Printf("NetHub: engine bridge required for actual Internet transport/mod download/AI HTTP.");
        }
    }
}

class NetAIAvatar : Actor
{
    Default
    {
        Radius 12;
        Height 28;
        +NOGRAVITY;
        +FLOAT;
        +NOTARGET;
        +NOINTERACTION;
        RenderStyle "Translucent";
        Alpha 0.85;
    }

    States
    {
    Spawn:
        AISP A 4 Bright;
        AISP B 4 Bright;
        AISP C 4 Bright;
        AISP B 4 Bright;
        Loop;
    }
}

class NetModVersion : StaticEventHandler
{
    override void OnRegister()
    {
        Console.Printf("UZDoom NetHub v0.1 prototype loaded.");
        Console.Printf("F10 = NetHub configuration, F11 = AI avatar test spawn.");
    }
}
