#!/data/data/com.termux/files/usr/bin/bash
set -e
SRC="$(cd "$(dirname "$0")/PK3_Source" && pwd)"
OUT="$(cd "$(dirname "$0")" && pwd)/UZDoom_NetHub_repacked.pk3"
cd "$SRC"
rm -f "$OUT"
zip -r -9 "$OUT" . >/dev/null
echo "Created: $OUT"
